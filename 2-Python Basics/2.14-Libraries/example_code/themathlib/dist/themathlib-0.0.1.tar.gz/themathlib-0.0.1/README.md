 # The Math Lib

- This is a basic package with simple geometric operations and basic math operations