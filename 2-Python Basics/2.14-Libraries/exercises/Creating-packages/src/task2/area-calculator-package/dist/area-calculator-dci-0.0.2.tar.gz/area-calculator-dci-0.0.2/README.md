# Area Calculator Package

This is a simple package, that allows for calculating area of given 2D figure.  
Available figures:  
  * square
  * rectangle
  * triangle
  * rhombus_with_diagonals
  * parallelogram
  * trapezoid

You can use [Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/) to write your content.